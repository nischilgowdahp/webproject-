// Registration logic
const registerForm = document.getElementById('register-form');
const registerError = document.getElementById('register-error');

registerForm.addEventListener('submit', function(e) {
  e.preventDefault();
  const email = document.getElementById('register-email').value.trim();
  const password = document.getElementById('register-password').value;

  if (!validateEmail(email)) {
    showError('Please enter a valid email address.');
    return;
  }
  if (password.length < 6) {
    showError('Password must be at least 6 characters.');
    return;
  }

  // Check if user already exists
  const users = JSON.parse(localStorage.getItem('recycleUsers') || '{}');
  if (users[email]) {
    showError('User already exists. Please login.');
    return;
  }

  // Register user
  users[email] = { password };
  localStorage.setItem('recycleUsers', JSON.stringify(users));
  localStorage.setItem('recycleUser', email);
  window.location.href = 'index.html';
});

function showError(msg) {
  registerError.textContent = msg;
  registerError.style.display = 'block';
}

function validateEmail(email) {
  return /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email);
}

// If already logged in, redirect to main app
if (localStorage.getItem('recycleUser')) {
  window.location.href = 'index.html';
}

// Admin login logic (demo: hardcoded admin)
const ADMIN_EMAIL = 'admin@gmail.com';
const ADMIN_PASS = 'admin123';

// Set default admin credentials in localStorage if not set
(function setDefaultAdmin() {
  const admins = JSON.parse(localStorage.getItem('recycleAdmins') || '{}');
  if (!admins[ADMIN_EMAIL]) {
    admins[ADMIN_EMAIL] = { password: ADMIN_PASS };
    localStorage.setItem('recycleAdmins', JSON.stringify(admins));
  }
})();

const adminLoginForm = document.getElementById('admin-login-form');
const adminLoginError = document.getElementById('admin-login-error');

adminLoginForm.addEventListener('submit', function(e) {
  e.preventDefault();
  const email = document.getElementById('admin-email').value.trim();
  const password = document.getElementById('admin-password').value;

  // Check credentials from localStorage admins
const admins = JSON.parse(localStorage.getItem('recycleAdmins') || '{}');
if (admins[email] && admins[email].password === password) {
    localStorage.setItem('recycleAdmin', 'true');
    window.location.href = 'admin.html';
  } else {
    adminLoginError.textContent = 'Invalid admin credentials.';
    adminLoginError.style.display = 'block';
  }
});

// If already logged in as admin, redirect
if (localStorage.getItem('recycleAdmin') === 'true') {
  window.location.href = 'admin.html';
}

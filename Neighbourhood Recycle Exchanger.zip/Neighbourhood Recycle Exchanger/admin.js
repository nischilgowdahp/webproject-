// Admin authentication (simple demo: hardcoded admin)
const ADMIN_EMAIL = 'admin@recycle.com';
const ADMIN_PASS = 'admin123';

// Require admin login
if (localStorage.getItem('recycleAdmin') !== 'true') {
  window.location.href = 'admin_login.html';
}

document.getElementById('admin-logout').onclick = () => {
  localStorage.removeItem('recycleAdmin');
  window.location.href = 'landing.html';
};

const table = document.querySelector('.admin-table');
const tbody = document.getElementById('admin-items-tbody');
const items = JSON.parse(localStorage.getItem('recycleItems') || '[]');
const users = JSON.parse(localStorage.getItem('recycleUsers') || '{}');

function renderAdminTable() {
  // Ensure proper thead/tbody structure
  let thead = table.querySelector('thead');
  if (!thead) {
    thead = document.createElement('thead');
    table.insertBefore(thead, table.firstChild);
  }
  thead.innerHTML = `
    <tr>
      <th>Item Title</th>
      <th>Owner (Email)</th>
      <th>Category</th>
      <th>Location</th>
      <th>Verified</th>
      <th>Photo</th>
      <th>Photo/Video</th>
      <th>Avg. Rating</th>
      <th>Actions</th>
    </tr>
  `;
  tbody.innerHTML = '';
  items.forEach((item, idx) => {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td>${item.title}</td>
      <td>${item.contact}</td>
      <td>${item.category}</td>
      <td>${item.location}</td>
      <td>${item.verified ? '✔' : '✖'}</td>
      <td>${item.image ? `<img src="${item.image}" width="50" height="50">` : '—'}</td>
      <td>${item.media ? `<a href="${item.media}" target="_blank">View</a>` : '—'}</td>
      <td>${item.avgRating ? item.avgRating.toFixed(1) : '0.0'}</td>
      <td>
        <button class="verify-btn" data-idx="${idx}" ${item.verified ? 'disabled' : ''}>Verify</button>
        <button class="unverify-btn" data-idx="${idx}" ${!item.verified ? 'disabled' : ''}>Unverify</button>
      </td>
    `;
    tbody.appendChild(tr);
  });
  // Add listeners
  document.querySelectorAll('.verify-btn').forEach(btn => {
    btn.onclick = function() {
      const i = +this.dataset.idx;
      items[i].verified = true;
      localStorage.setItem('recycleItems', JSON.stringify(items));
      renderAdminTable();
    };
  });
  document.querySelectorAll('.unverify-btn').forEach(btn => {
    btn.onclick = function() {
      const i = +this.dataset.idx;
      items[i].verified = false;
      localStorage.setItem('recycleItems', JSON.stringify(items));
      renderAdminTable();
    };
  });
}
renderAdminTable();

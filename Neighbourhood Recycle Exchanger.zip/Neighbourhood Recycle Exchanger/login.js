// Login validation and user check
const loginForm = document.getElementById('login-form');
const loginError = document.getElementById('login-error');

loginForm.addEventListener('submit', function(e) {
  e.preventDefault();
  const email = document.getElementById('login-email').value.trim();
  const password = document.getElementById('login-password').value;

  if (!validateEmail(email)) {
    showError('Please enter a valid email address.');
    return;
  }
  if (password.length < 6) {
    showError('Password must be at least 6 characters.');
    return;
  }

  // Check registered users
  const users = JSON.parse(localStorage.getItem('recycleUsers') || '{}');
  if (!users[email]) {
    showError('User not found. Please <a href="register.html">register here</a>.');
    return;
  }
  if (users[email].password !== password) {
    showError('Incorrect password.');
    return;
  }

  // Success: log in
  localStorage.setItem('recycleUser', email);
  window.location.href = 'index.html';
});

function showError(msg) {
  loginError.innerHTML = msg;
  loginError.style.display = 'block';
}

function validateEmail(email) {
  return /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email);
}

// If already logged in, redirect to main app
if (localStorage.getItem('recycleUser')) {
  window.location.href = 'index.html';
}

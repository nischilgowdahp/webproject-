// Neighborhood Recycle Exchange Script

// Tab switching logic
const tabButtons = document.querySelectorAll('.tab-btn');
const tabSections = [
  document.getElementById('home-section'),
  document.getElementById('add-item-section'),
  document.getElementById('browse-section')
];

tabButtons.forEach(btn => {
  btn.addEventListener('click', () => {
    // Remove active class from all buttons
    tabButtons.forEach(b => b.classList.remove('active'));
    // Add active class to clicked button
    btn.classList.add('active');
    // Show the relevant section and hide others
    tabSections.forEach(section => {
      if (section.id === btn.dataset.tab) {
        section.style.display = '';
      } else {
        section.style.display = 'none';
      }
    });
  });
});

// Logout logic
const logoutBtn = document.getElementById('logout-btn');
if (logoutBtn) {
  logoutBtn.addEventListener('click', () => {
    localStorage.removeItem('recycleUser');
    window.location.href = 'landing.html';
  });
}


// Array to store items in-memory
let items = [];

// Load items from localStorage on page load
if (localStorage.getItem('recycleItems')) {
  try {
    items = JSON.parse(localStorage.getItem('recycleItems')) || [];
  } catch (e) {
    items = [];
  }
}

// DOM Elements
const addItemForm = document.getElementById('add-item-form');
const itemsList = document.getElementById('items-list');
const filterCategory = document.getElementById('filter-category');
const applyFiltersBtn = document.getElementById('apply-filters');


// Template for item card
const itemTemplate = document.getElementById('item-template');

// Helper: Create mailto link
function createMailtoLink(email, title) {
  const subject = encodeURIComponent(`Interested in your item: ${title}`);
  const body = encodeURIComponent('Hi,\n\nI saw your listing on Neighborhood Recycle Exchange and would like to arrange a pickup.\n\nThanks!');
  return `mailto:${email}?subject=${subject}&body=${body}`;
}

// Render items to the list
// Initial render on page load
renderFilteredItems();

function renderFilteredItems() {
  const selectedCategory = filterCategory.value;
  let filtered = items;
  if (selectedCategory) {
    filtered = filtered.filter(item => item.category === selectedCategory);
  }
  renderItems(filtered);
}

function renderItems(list) {
  itemsList.innerHTML = '';

  if (list.length === 0) {
    itemsList.innerHTML = '<p>No items match your filters.</p>';
    return;
  }

  list.forEach((item) => {
    const clone = itemTemplate.content.cloneNode(true);
    clone.querySelector('.item-title').textContent = item.title;
    clone.querySelector('.item-meta').textContent = `${item.category} • ${item.location}`;
    clone.querySelector('.item-description').textContent = item.description || 'No description.';
    clone.querySelector('.contact-btn').href = createMailtoLink(item.contact, item.title);

    // Render image if present
    if (item.image) {
      const img = clone.querySelector('.item-image');
      img.src = item.image;
      img.style.display = 'block';
    }
    // Render media if present
    if (item.media) {
      const mediaLink = clone.querySelector('.item-media-link');
      mediaLink.href = item.media;
      mediaLink.style.display = 'inline-block';
      mediaLink.textContent = item.media.startsWith('data:video') ? 'View Video' : 'View Photo';
    }
    // Show verified/unverified label below item name
    const verifyLabel = clone.querySelector('.verify-status-label');
    if (item.verified) {
      verifyLabel.textContent = '✔ Verified';
      verifyLabel.style.color = '#2a9d8f';
    } else {
      verifyLabel.textContent = '✖ Unverified';
      verifyLabel.style.color = '#b00020';
    }
    // Render rating
    const ratingStars = clone.querySelector('.rating-stars');
    const ratingValue = clone.querySelector('.rating-value');
    ratingValue.textContent = (item.avgRating || 0).toFixed(1);
    ratingStars.textContent = '★★★★★'.slice(0, Math.round(item.avgRating || 0)) + '☆☆☆☆☆'.slice(Math.round(item.avgRating || 0));
    // Rating buttons
    clone.querySelectorAll('.rate-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const val = parseInt(btn.dataset.value);
        if (!localStorage.getItem('recycleUser')) {
          alert('Please log in to rate items.');
          return;
        }
        if (!item.ratings) item.ratings = [];
        item.ratings.push(val);
        item.avgRating = item.ratings.reduce((a,b)=>a+b,0)/item.ratings.length;
        localStorage.setItem('recycleItems', JSON.stringify(items));
        renderItems(items);
      });
    });
    itemsList.appendChild(clone);
  });
}

// Add item handler
addItemForm.addEventListener('submit', (e) => {
  e.preventDefault();

  // Handle image upload
  const imageInput = document.getElementById('image');
  const mediaInput = document.getElementById('media');
  let imageData = '';
  let mediaData = '';
  if (imageInput.files && imageInput.files[0]) {
    const reader = new FileReader();
    reader.onload = function(e) {
      imageData = e.target.result;
      saveItem();
    };
    reader.readAsDataURL(imageInput.files[0]);
  } else {
    saveItem();
  }
  function saveItem() {
    if (mediaInput.files && mediaInput.files[0]) {
      const reader2 = new FileReader();
      reader2.onload = function(e) {
        mediaData = e.target.result;
        finalize();
      };
      reader2.readAsDataURL(mediaInput.files[0]);
    } else {
      finalize();
    }
  }
  function finalize() {
    const newItem = {
      title: document.getElementById('title').value.trim(),
      category: document.getElementById('category').value,
      location: document.getElementById('location').value.trim(),
      contact: document.getElementById('contact').value.trim(),
      description: document.getElementById('description').value.trim(),
      image: imageData,
      media: mediaData,
      verified: false,
      ratings: [],
      avgRating: 0
    };
    items.push(newItem);
    localStorage.setItem('recycleItems', JSON.stringify(items));
    addItemForm.reset();
    renderItems(items);
  }
  renderItems(items);
});

// Filter handler
applyFiltersBtn.addEventListener('click', () => {
  renderFilteredItems();
});

// Browse tab handler
browseTabBtns.forEach(btn => {
  btn.addEventListener('click', () => {
    browseTabBtns.forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    currentBrowseTab = btn.dataset.browsetab;
    renderFilteredItems();
  });
});

// Initial render
renderItems(items);
